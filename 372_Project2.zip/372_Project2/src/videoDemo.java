public class videoDemo {
	public static void main(String[] args){
int[] myArray = {9,8,7,6,100};
double pi = 3.14;
int x = 2;
double pi2 = pi * x;
double answer = 0.00;
for(int r : myArray){
	answer = pi2 * r;
	System.out.println(answer);
}

}
}