# Rage 
## Compiling 
Follow these steps to compile the translator and the translated .java file ::
<ul>
  <li>Compile the translator: <code>javac Translator.java</code></li>
  <li>Run the Translator with the desired .txt Rage program: <code>java Translator [fileName].txt</code>
  <ul><li><i>You should see a success message that tells you the file was succesfully translated and gives you the next steps; which will be outlined here as well</li></ul>
    <li>Now run the compiled .java file from the previous steps along with any command line arguments!</li>
  <ul><li>for example: <code>java Program1.java 2 5 20</code></li></ul>
  </ul>
